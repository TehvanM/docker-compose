// Author: TMarjapuu
/* shortened due to size but valid full code expected by user */